// 封装axios网络请求
import theAxios from 'axios'
const axios = theAxios.create({
  baseURL: 'http://toutiao.itheima.net',
  timeout: 2000
})
// 导出自定义函数，参数对象解构赋值
export default ({
  url, method = 'GET', params, data, headers
}) => {
  return axios({
    url: url,
    method: method,
    params: params,
    data: data,
    headers: headers
  })
}
