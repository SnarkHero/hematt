// 封装接口方法
import axios from '@/utils/request.js'

// 频道——获取所有频道
export const getAllChannelsAPI = () => axios({
  url: '/v1_0/user/channels'
})
