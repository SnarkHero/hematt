<template>
  <div>
    <van-nav-bar title="黑马头条-登录" />
  </div>
</template>

<script>
export default {}
</script>

// <style scoped lang="less">
// // scoped中加/deep/data-v-hash值选择器写到类名的前面,lang='less'是启用less语法
// .van-nav-bar{
//    background: #007bff;
// }
// /deep/ .van-nav-bar__title{
// color: white;
// }
</style>
